<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
</head>
<body>  

<?php
// define variables and set to empty values
$nameErr =$expErr= $emailErr = $genderErr  = "";
$name = $email = $gender =$experience = "";
?>

<h2>PHP Form Validation Example</h2>
<p><span class="error">* required field</span></p>
<form method="post" action="res.php">  
  Name: <input type="text" name="name" value="<?php echo $name;?>">
  <span class="error">* <?php echo $nameErr;?></span>
  <br><br>
  E-mail: <input type="text" name="email" value="<?php echo $email;?>">
  <span class="error">* <?php echo $emailErr;?></span>
  <br><br>
 

  Gender:
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?> value="female">Female
  <input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?> value="male">Male
  <span class="error">* <?php echo $genderErr;?></span>
  <br><br>

  experience:<br>
  <input type="checkbox" name="experience" <?php if (isset($experience) && $experience=="fresher") echo "checked";?> value="fresher">fresher <br>
  <input type="checkbox" name="experience" <?php if (isset($experience) && $experience=="experience") echo "checked";?> value="experience">experience
  <span class="error">* <?php echo $expErr;?></span> <br><br>

  <input type="submit" name="submit" value="Submit">  


</form>


</body>
</html>